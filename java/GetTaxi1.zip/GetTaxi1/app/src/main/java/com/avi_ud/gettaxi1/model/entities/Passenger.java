package com.avi_ud.gettaxi1.model.entities;

//This is the Passenger class
public class Passenger extends Person {

    //constructor
    public Passenger(){}

    public Passenger(String lastName, String firstName, String id, String phoneNumber, String email) {
        super(lastName, firstName, id, phoneNumber, email);
    }


}
