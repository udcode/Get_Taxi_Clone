package com.avi_ud.gettaxi1.model.entities;

public enum RideStatus {
    OPEN,IN_PROGRESS,DONE
}
