package com.avi_ud.gettaxi1.controller;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.avi_ud.gettaxi1.R;

public class ProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
    }
}
