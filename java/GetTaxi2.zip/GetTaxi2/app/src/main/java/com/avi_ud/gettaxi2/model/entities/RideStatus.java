package com.avi_ud.gettaxi2.model.entities;

public enum RideStatus {
    OPEN,IN_PROGRESS,DONE
}
